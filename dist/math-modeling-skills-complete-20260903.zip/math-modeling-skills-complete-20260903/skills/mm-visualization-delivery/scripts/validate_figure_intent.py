#!/usr/bin/env python3
"""Validate CUMCM FIGURE_PLAN / FIGURE_INTENT artifacts.

The planner is reader-task driven and deliberately imposes no fixed figure quota.
The renderer side remains fail-closed: sources, hashes, renderer specs, runtime
contracts, reopen checks, visual grammar, and native-backend audit evidence are
validated before an output can be treated as final.

This checker validates structure and artifact integrity, not scientific truth.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import zipfile
from pathlib import Path
from typing import Any

ROLE_SET = {"orientation", "mechanism", "evidence", "validation"}
PLACEMENTS = {"body", "appendix"}
REPRESENTATIONS = {"figure", "table", "text", "appendix", "not_applicable"}
READER_TASKS = {"orientation", "mechanism", "main_result", "comparison", "validation", "robustness"}
STYLE_PROFILES = {
    "cumcm-clean", "cumcm-highlight", "cumcm-data-dense", "cumcm-vivid", "cumcm-mechanism"
}
LEGEND_STRATEGIES = {"top", "right", "inside", "direct", "none", "colorbar"}
EXACT_VALUE_LOCATIONS = {
    "result_table", "machine_readable_table", "figure_annotation", "caption", "not_applicable"
}
VISUAL_GRAMMAR_FIELDS = {
    "font_family", "base_font_pt", "palette", "line_width_pt", "style_profile",
    "final_width_mm", "legend_strategy", "precision_policy", "decorative_effects",
}
PATH_KEYS = {"file", "path", "source", "source_file", "files", "paths", "source_files"}
SINGULAR_PATH_KEYS = {"file", "path", "source", "source_file"}

DATA_TYPES = {
    "line", "line_chart", "scatter", "scatter_plot", "bar", "bar_chart", "horizontal_bar",
    "grouped_bar", "stacked_bar", "box", "boxplot", "violin", "histogram", "density",
    "heatmap", "trajectory", "map", "contour", "errorbar", "area", "scatter_matrix",
    "vector_field", "pareto", "dumbbell", "slope", "interval_band", "interval_timeline",
    "sensitivity", "convergence", "data_plot", "surface_3d", "bar_3d", "radar", "pie",
    "donut", "dual_axis", "scatter_2d", "scatter_3d", "log_x", "log_y", "log_xy",
    "line_interval", "surface_wireframe", "area_3d", "step", "stem", "bubble", "parallel_coordinates",
}
DIAGRAM_TYPES = {
    "flowchart", "workflow", "architecture", "structural", "state_machine", "sequence",
    "network", "topology", "decision_tree", "mechanism", "diagram", "geometry", "case_diagram",
    "coordinate_system", "free_body_diagram",
}
DATA_BACKENDS = {"origin", "matlab", "python", "python/matplotlib", "matplotlib"}
GENERATIVE_BACKENDS = {"image2", "imagegen"}
DIAGRAM_BACKENDS = {"visio", "figurespec", "figurespec/svg", "svg", "mermaid"} | GENERATIVE_BACKENDS
RESTRICTED_TYPES = {"radar", "pie", "donut", "dual_axis", "surface_3d", "bar_3d", "scatter_3d", "surface_wireframe", "area_3d", "parallel_coordinates"}

REQUIRED_FIGURE_FIELDS = (
    "figure_id", "question_id", "purpose", "source_data", "variables", "units",
    "transformations", "chart_or_diagram_type", "backend_preference", "editable_output",
    "latex_output", "caption_zh", "narrative_role", "reader_takeaway", "exact_values_location",
    "visual_grammar_group", "visual_grammar", "placement",
)
ZH_RE = re.compile(r"[\u3400-\u9fff]")
HEX64_RE = re.compile(r"[0-9a-f]{64}")


def load_document(path: Path) -> Any:
    text = path.read_text(encoding="utf-8-sig")
    if path.suffix.lower() == ".json":
        return json.loads(text)
    try:
        import yaml  # type: ignore
    except ImportError as exc:
        raise RuntimeError("YAML input requires PyYAML; use JSON or install PyYAML") from exc
    return yaml.safe_load(text)


def nonempty(value: Any) -> bool:
    return value is not None and value not in ("", [], {})


def specific_reason(value: Any) -> bool:
    text = str(value or "").strip()
    return len(text) >= 8 and text.lower() not in {"n/a", "na", "none", "not applicable", "不适用"}


def collect_string_values(value: Any) -> list[str]:
    if isinstance(value, str):
        return [value]
    if isinstance(value, list):
        found: list[str] = []
        for child in value:
            found.extend(collect_string_values(child))
        return found
    return []


def collect_paths(value: Any) -> list[str]:
    """Collect only values under explicit path keys; never interpret hashes as paths."""
    found: list[str] = []
    if isinstance(value, dict):
        for key, child in value.items():
            if str(key).lower() in PATH_KEYS:
                found.extend(collect_string_values(child))
            elif isinstance(child, (dict, list)):
                found.extend(collect_paths(child))
    elif isinstance(value, list):
        for child in value:
            if isinstance(child, (dict, list)):
                found.extend(collect_paths(child))
    return found


def declared_hash_for_path(value: Any, source_path: str, total_paths: int) -> str:
    if isinstance(value, list):
        for child in value:
            declared = declared_hash_for_path(child, source_path, total_paths)
            if declared:
                return declared
        return ""
    if not isinstance(value, dict):
        return ""

    direct_paths: list[str] = []
    for key, child in value.items():
        if str(key).lower() in SINGULAR_PATH_KEYS:
            direct_paths.extend(collect_string_values(child))
    if source_path in direct_paths and isinstance(value.get("sha256"), str):
        return str(value["sha256"]).strip().lower()

    for mapping_key in ("sha256", "hashes"):
        mapping = value.get(mapping_key)
        if isinstance(mapping, dict) and isinstance(mapping.get(source_path), str):
            return str(mapping[source_path]).strip().lower()

    if total_paths == 1 and isinstance(value.get("sha256"), str):
        return str(value["sha256"]).strip().lower()

    for child in value.values():
        if isinstance(child, (dict, list)):
            declared = declared_hash_for_path(child, source_path, total_paths)
            if declared:
                return declared
    return ""


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def normalize_entries(document: Any) -> list[dict[str, Any]]:
    if isinstance(document, list):
        entries = document
    elif isinstance(document, dict) and isinstance(document.get("figures"), list):
        entries = document["figures"]
    elif isinstance(document, dict) and "figure_id" in document:
        entries = [document]
    elif isinstance(document, dict) and isinstance(document.get("coverage_plan"), dict):
        entries = []
    else:
        raise ValueError("Root must be a figure, a list, or an object with figures/coverage_plan")
    if not all(isinstance(item, dict) for item in entries):
        raise ValueError("Every figure entry must be an object")
    return entries


def normalized_claim_ids(value: Any) -> set[str]:
    if isinstance(value, str):
        return {value.strip()} if value.strip() else set()
    if isinstance(value, list):
        return {str(item).strip() for item in value if str(item).strip()}
    return set()


def basic_output_reopen_error(path: Path) -> str | None:
    suffix = path.suffix.lower()
    if suffix == ".pdf":
        data = path.read_bytes()
        if len(data) < 256 or not data.startswith(b"%PDF-") or b"%%EOF" not in data[-2048:]:
            return "incomplete PDF header/body/EOF"
    elif suffix == ".png":
        data = path.read_bytes()
        if len(data) < 64 or not data.startswith(b"\x89PNG\r\n\x1a\n") or b"IEND" not in data[-64:]:
            return "incomplete PNG signature/IEND"
    elif suffix == ".vsdx":
        if not zipfile.is_zipfile(path):
            return "not a reopenable OOXML ZIP package"
        with zipfile.ZipFile(path) as archive:
            if archive.testzip() is not None or "visio/document.xml" not in archive.namelist():
                return "corrupt or incomplete Visio package"
    elif suffix == ".opju":
        data = path.read_bytes()
        if len(data) < 1024 or not data.startswith(b"CPYUA"):
            return "does not resemble a complete Origin project"
    elif suffix == ".fig":
        data = path.read_bytes()
        if len(data) < 1024 or not (data.startswith(b"MATLAB") or data.startswith(b"\x89HDF")):
            return "does not resemble a complete MATLAB figure"
    return None


def validate_visual_grammar(entry: dict[str, Any], prefix: str, require_outputs: bool) -> list[str]:
    errors: list[str] = []
    grammar = entry.get("visual_grammar")
    if not isinstance(grammar, dict):
        return [f"{prefix}.visual_grammar: required and must be an object"]

    missing = sorted(field for field in VISUAL_GRAMMAR_FIELDS if field not in grammar or grammar[field] in (None, "", {}))
    if missing:
        errors.append(f"{prefix}.visual_grammar: missing {', '.join(missing)}")

    profile = str(grammar.get("style_profile", "")).strip().lower()
    if profile and profile not in STYLE_PROFILES:
        errors.append(f"{prefix}.visual_grammar.style_profile: unknown '{profile}'")
    legend = str(grammar.get("legend_strategy", "")).strip().lower()
    if legend and legend not in LEGEND_STRATEGIES:
        errors.append(f"{prefix}.visual_grammar.legend_strategy: unknown '{legend}'")

    font_pt = grammar.get("base_font_pt")
    if not isinstance(font_pt, (int, float)) or float(font_pt) < 7:
        errors.append(f"{prefix}.visual_grammar.base_font_pt: must be numeric and at least 7 pt")
    width = grammar.get("final_width_mm")
    if not isinstance(width, (int, float)) or not 65 <= float(width) <= 180:
        errors.append(f"{prefix}.visual_grammar.final_width_mm: must be between 65 and 180 mm")
    line_width = grammar.get("line_width_pt")
    if not isinstance(line_width, (int, float)) or float(line_width) <= 0:
        errors.append(f"{prefix}.visual_grammar.line_width_pt: must be positive")
    palette = grammar.get("palette")
    if not isinstance(palette, list) or not palette:
        errors.append(f"{prefix}.visual_grammar.palette: must be a non-empty list")
    effects = grammar.get("decorative_effects")
    if not isinstance(effects, list):
        errors.append(f"{prefix}.visual_grammar.decorative_effects: must be a list")
        effects = []

    active_effects = [
        str(effect).strip().lower()
        for effect in effects
        if str(effect).strip() and str(effect).strip().lower() != "none"
    ]
    if active_effects:
        semantics = str(entry.get("effect_semantics", "")).strip().lower()
        if semantics not in {"nonsemantic", "encoded"}:
            errors.append(f"{prefix}.effect_semantics: active effects require 'nonsemantic' or 'encoded'")
        if semantics == "encoded" and not nonempty(entry.get("effect_encoding_variable")):
            errors.append(f"{prefix}.effect_encoding_variable: required when an effect encodes data")
        if require_outputs:
            audit = entry.get("effect_audit")
            required_checks = {
                "occlusion_check", "grayscale_check", "final_size_check"
            }
            if semantics == "encoded":
                required_checks.add("effect_removed_comparison")
            if not isinstance(audit, dict):
                errors.append(f"{prefix}.effect_audit: required for final outputs with decorative effects")
            else:
                for check in sorted(required_checks):
                    if str(audit.get(check, "")).upper() != "PASSED":
                        errors.append(f"{prefix}.effect_audit.{check}: must be PASSED")
    return errors


def report_output_hashes(report: Any) -> set[str]:
    hashes: set[str] = set()
    if not isinstance(report, dict):
        return hashes
    for key in ("opju_sha256", "vsdx_sha256", "pdf_sha256"):
        value = report.get(key)
        if isinstance(value, str) and re.fullmatch(r"[0-9a-fA-F]{64}", value):
            hashes.add(value.lower())
    outputs = report.get("outputs")
    if isinstance(outputs, list):
        for item in outputs:
            if isinstance(item, dict):
                value = item.get("sha256")
                if isinstance(value, str) and re.fullmatch(r"[0-9a-fA-F]{64}", value):
                    hashes.add(value.lower())
    spec = report.get("spec")
    if isinstance(spec, dict):
        value = spec.get("sha256")
        if isinstance(value, str) and re.fullmatch(r"[0-9a-fA-F]{64}", value):
            hashes.add(value.lower())
    return hashes


def normalize_chart_type(value: Any) -> str:
    chart = str(value or "").strip().lower().replace(" ", "_")
    return {"line_chart": "line", "scatter_plot": "scatter", "boxplot": "box"}.get(chart, chart)


def validate_backend_report(
    entry: dict[str, Any], prefix: str, base_dir: Path,
    editable_hash: str, latex_hash: str,
) -> list[str]:
    """Keep rendering/integrity checks strict even though figure-count checks are relaxed."""
    errors: list[str] = []
    report_value = entry.get("backend_report")
    if not isinstance(report_value, str) or not report_value.strip():
        return [f"{prefix}.backend_report: required in final output mode"]
    report_path = Path(report_value)
    if not report_path.is_absolute():
        report_path = base_dir / report_path
    if not report_path.is_file():
        return [f"{prefix}.backend_report: missing file {report_path}"]

    declared_report_hash = str(entry.get("backend_report_sha256", "")).strip().lower()
    if not HEX64_RE.fullmatch(declared_report_hash):
        errors.append(f"{prefix}.backend_report_sha256: required as 64 hexadecimal characters")
    elif file_sha256(report_path) != declared_report_hash:
        errors.append(f"{prefix}.backend_report_sha256: does not match {report_path}")

    try:
        report = json.loads(report_path.read_text(encoding="utf-8-sig"))
    except Exception as exc:
        errors.append(f"{prefix}.backend_report: unreadable JSON: {type(exc).__name__}: {exc}")
        return errors

    status = str(report.get("status", "")).upper()
    if status not in {"PASSED", "RUNTIME_VERIFIED"}:
        errors.append(f"{prefix}.backend_report.status: expected PASSED/RUNTIME_VERIFIED, got '{status}'")

    hashes = report_output_hashes(report)
    for label, output_hash in (("editable", editable_hash), ("latex", latex_hash)):
        if output_hash and output_hash not in hashes:
            errors.append(f"{prefix}.backend_report: {label} output hash is not recorded by the runtime report")

    backend = str(entry.get("backend_preference", "")).strip().lower()
    grammar = entry.get("visual_grammar") if isinstance(entry.get("visual_grammar"), dict) else {}
    style = report.get("style") if isinstance(report.get("style"), dict) else report

    declared_style = str(grammar.get("style_profile", "")).strip().lower()
    reported_style = str(style.get("style_profile", "")).strip().lower()
    if declared_style and reported_style != declared_style:
        errors.append(
            f"{prefix}.backend_report.style_profile: runtime '{reported_style}' does not match declared '{declared_style}'"
        )

    if backend in DATA_BACKENDS:
        declared_palette = grammar.get("palette")
        reported_palette = style.get("effective_palette")
        if isinstance(reported_palette, str) and reported_palette.strip():
            reported_palette = [reported_palette]
        if not isinstance(reported_palette, list) or not reported_palette:
            errors.append(f"{prefix}.backend_report.effective_palette: required for data backends")
        elif isinstance(declared_palette, list):
            lhs = [str(color).strip().upper() for color in declared_palette]
            rhs = [str(color).strip().upper() for color in reported_palette]
            if rhs[: len(lhs)] != lhs:
                errors.append(f"{prefix}.backend_report.effective_palette: does not match visual_grammar.palette")

        declared_effects = {
            str(effect).strip().lower() for effect in grammar.get("decorative_effects", [])
        }
        reported_effects_value = style.get("decorative_effects")
        reported_effects = {
            str(effect).strip().lower() for effect in reported_effects_value
        } if isinstance(reported_effects_value, list) else set()
        if reported_effects != declared_effects:
            errors.append(f"{prefix}.backend_report.decorative_effects: must match visual_grammar")

    if backend in {"matlab", "python", "python/matplotlib", "matplotlib"}:
        renderer_spec = entry.get("renderer_spec")
        spec_paths = collect_paths(renderer_spec)
        declared_spec_hash = ""
        if not isinstance(renderer_spec, dict) or len(spec_paths) != 1:
            errors.append(f"{prefix}.renderer_spec: exactly one hash-bound renderer spec is required")
        else:
            declared_spec_hash = declared_hash_for_path(renderer_spec, spec_paths[0], 1)
            spec_path = Path(spec_paths[0])
            if not spec_path.is_absolute():
                spec_path = base_dir / spec_path
            if not HEX64_RE.fullmatch(declared_spec_hash):
                errors.append(f"{prefix}.renderer_spec.sha256: required as 64 hexadecimal characters")
            elif not spec_path.is_file() or file_sha256(spec_path) != declared_spec_hash:
                errors.append(f"{prefix}.renderer_spec.sha256: does not match renderer spec file")

        report_spec = report.get("spec")
        report_spec_hash = str(report_spec.get("sha256", "")).lower() if isinstance(report_spec, dict) else ""
        if declared_spec_hash and report_spec_hash != declared_spec_hash:
            errors.append(f"{prefix}.backend_report.spec.sha256: does not match renderer_spec.sha256")

        contract = report.get("render_contract")
        if not isinstance(contract, dict):
            errors.append(f"{prefix}.backend_report.render_contract: required")
        else:
            if normalize_chart_type(entry.get("chart_or_diagram_type")) != normalize_chart_type(contract.get("chart_type")):
                errors.append(f"{prefix}.backend_report.render_contract.chart_type: does not match intent")
            declared_variables = [str(value) for value in entry.get("variables", [])]
            contract_variables = [str(value) for value in contract.get("variables", [])] if isinstance(contract.get("variables"), list) else []
            if declared_variables != contract_variables:
                errors.append(f"{prefix}.backend_report.render_contract.variables: does not match intent")
            declared_transform = json.dumps(entry.get("transformations"), ensure_ascii=False, sort_keys=True)
            contract_transform = json.dumps(contract.get("transformations"), ensure_ascii=False, sort_keys=True)
            if declared_transform != contract_transform:
                errors.append(f"{prefix}.backend_report.render_contract.transformations: does not match intent")

        for grammar_field, report_field, tolerance in (
            ("final_width_mm", "final_width_mm", 0.05),
            ("line_width_pt", "line_width_pt", 0.01),
            ("base_font_pt", "base_font_pt", 0.01),
        ):
            declared_value = grammar.get(grammar_field)
            reported_value = style.get(report_field)
            if not isinstance(declared_value, (int, float)) or not isinstance(reported_value, (int, float)) or abs(float(declared_value) - float(reported_value)) > tolerance:
                errors.append(f"{prefix}.backend_report.{report_field}: must match visual_grammar.{grammar_field}")

        effective_font = style.get("effective_min_font_pt")
        if not isinstance(effective_font, (int, float)) or float(effective_font) < 7:
            errors.append(f"{prefix}.backend_report.effective_min_font_pt: must be at least 7 pt at final width")
        declared_font = str(grammar.get("font_family", "")).strip().casefold()
        reported_font = str(style.get("font_family", "")).strip().casefold()
        if not reported_font or reported_font != declared_font:
            errors.append(f"{prefix}.backend_report.font_family: runtime font must match visual_grammar.font_family")
        if str(style.get("legend_strategy", "")).strip().lower() != str(grammar.get("legend_strategy", "")).strip().lower():
            errors.append(f"{prefix}.backend_report.legend_strategy: must match visual_grammar")
        reopen = report.get("reopen_check")
        if not isinstance(reopen, dict) or not reopen or not all(value is True for value in reopen.values()):
            errors.append(f"{prefix}.backend_report.reopen_check: every recorded output must be true")

    elif backend == "origin":
        for field in (
            "project_saved", "pdf_exported", "project_reopened", "pdf_reopened",
            "metadata_sanitized", "anonymous_check",
        ):
            if report.get(field) is not True:
                errors.append(f"{prefix}.backend_report.{field}: must be true for Origin")
        effective_font = report.get("effective_min_font_pt")
        if not isinstance(effective_font, (int, float)) or float(effective_font) < 7:
            errors.append(f"{prefix}.backend_report.effective_min_font_pt: must be at least 7 pt")
        declared_width = grammar.get("final_width_mm")
        reported_width = report.get("final_width_mm")
        if not isinstance(declared_width, (int, float)) or not isinstance(reported_width, (int, float)) or abs(float(declared_width) - float(reported_width)) > 0.05:
            errors.append(f"{prefix}.backend_report.final_width_mm: must match visual_grammar")

    elif backend == "visio":
        for field in (
            "document_saved", "pdf_exported", "document_reopened", "pdf_reopened",
            "metadata_sanitized", "anonymous_check",
        ):
            if report.get(field) is not True:
                errors.append(f"{prefix}.backend_report.{field}: must be true for Visio")
        if int(report.get("unsupported_groups", 0) or 0) != 0:
            errors.append(f"{prefix}.backend_report.unsupported_groups: must be zero")
        effective_font = report.get("effective_min_font_pt")
        if not isinstance(effective_font, (int, float)) or float(effective_font) < 7:
            errors.append(f"{prefix}.backend_report.effective_min_font_pt: must be at least 7 pt")
        for grammar_field, report_field, tolerance in (
            ("final_width_mm", "final_width_mm", 0.05),
            ("base_font_pt", "base_font_pt", 0.05),
            ("line_width_pt", "line_width_pt", 0.05),
        ):
            declared_value = grammar.get(grammar_field)
            reported_value = report.get(report_field)
            if not isinstance(declared_value, (int, float)) or not isinstance(reported_value, (int, float)) or abs(float(declared_value) - float(reported_value)) > tolerance:
                errors.append(f"{prefix}.backend_report.{report_field}: must match visual_grammar.{grammar_field}")
        if str(report.get("legend_strategy", "")).lower() != str(grammar.get("legend_strategy", "")).lower():
            errors.append(f"{prefix}.backend_report.legend_strategy: must match visual_grammar")
        declared_effects = {str(effect).strip().lower() for effect in grammar.get("decorative_effects", [])}
        reported_effects = {str(effect).strip().lower() for effect in report.get("decorative_effects", [])} if isinstance(report.get("decorative_effects"), list) else set()
        if reported_effects != declared_effects:
            errors.append(f"{prefix}.backend_report.decorative_effects: must match visual_grammar")
        declared_palette = {str(color).strip().upper() for color in grammar.get("palette", [])}
        reported_palette = {str(color).strip().upper() for color in report.get("effective_palette", [])} if isinstance(report.get("effective_palette"), list) else set()
        if not declared_palette.issubset(reported_palette):
            errors.append(f"{prefix}.backend_report.effective_palette: must contain declared colors")
        declared_font = re.sub(r"[^a-z0-9]", "", str(grammar.get("font_family", "")).lower())
        pdf_fonts = [
            re.sub(r"[^a-z0-9]", "", str(font).lower())
            for font in report.get("pdf_fonts", [])
        ] if isinstance(report.get("pdf_fonts"), list) else []
        if not declared_font or not any(declared_font in font or font in declared_font for font in pdf_fonts if font):
            errors.append(f"{prefix}.backend_report.pdf_fonts: declared font was not embedded")

    elif backend in GENERATIVE_BACKENDS:
        from visual_review_contract import bound_file
        from scientific_illustration import choose_backend, validate_brief
        if report.get("actual_backend") != backend:
            errors.append(f"{prefix}.backend_report.actual_backend: renderer mismatch")
        if report.get("editability") != "prompt_and_spec_only":
            errors.append(f"{prefix}.backend_report.editability: raster is not an editable vector")
        try:
            receipt_path = bound_file(report.get("receipt"), report_path.parent, "generation receipt")
            receipt = load_document(receipt_path)
            request_path = bound_file(receipt.get("request"), receipt_path.parent, "generation request")
            request = load_document(request_path)
            prompt_path = bound_file(receipt.get("prompt"), receipt_path.parent, "generation prompt")
            record_path = bound_file(receipt.get("tool_record"), receipt_path.parent, "native tool record")
            record = load_document(record_path)
            generation_brief_path = bound_file(report.get("generation_brief"), report_path.parent,
                                               "original generation brief")
            generation_brief = load_document(generation_brief_path)
            if not all(isinstance(item, dict) for item in (receipt, request, record, generation_brief)):
                raise ValueError("receipt, request, tool record, and generation brief must be objects")
            tool = receipt.get("tool_name", "")
            names = request.get("tool_names")
            if not isinstance(names, list) or not all(isinstance(name, str) for name in names):
                raise ValueError("request.tool_names must list the actual discovered tools")
            valid_generator = tool in {"image_gen__imagegen", "image_gen.imagegen"} if backend == "imagegen" else (
                isinstance(tool, str) and "codex" in tool and "image2" in tool and
                (tool.endswith("__generate") or tool.endswith("__generate_start")))
            if not valid_generator or tool not in names:
                raise ValueError("receipt.tool_name must identify the requested generator, not a companion/status tool")
            choose_backend(backend, names)
            if request.get("actual_backend") != backend or request.get("status") != "READY_TO_CALL_NOT_GENERATED":
                raise ValueError("request backend/status does not match the generation contract")
            if request.get("prompt_sha256") != file_sha256(prompt_path):
                raise ValueError("request prompt binding is stale")
            original_hash = file_sha256(generation_brief_path)
            if request.get("brief_sha256") != original_hash or report.get("generation_brief_sha256") != original_hash:
                raise ValueError("request/report original brief binding is stale")
            if request.get("source_files") != generation_brief.get("source_files"):
                raise ValueError("request source bindings differ from original generation brief")
            editable_path = Path(entry["editable_output"])
            editable_path = editable_path if editable_path.is_absolute() else base_dir / editable_path
            editable_brief = load_document(editable_path)
            validate_brief(editable_brief, editable_path.parent)
            original_content = {key: value for key, value in generation_brief.items() if key != "source_files"}
            editable_content = {key: value for key, value in editable_brief.items() if key != "source_files"}
            if original_content != editable_content:
                raise ValueError("editable brief differs from the brief used for generation")
            original_sources = generation_brief.get("source_files", [])
            current_sources = editable_brief.get("source_files", [])
            if [source["sha256"] for source in original_sources] != [source["sha256"] for source in current_sources]:
                raise ValueError("editable brief source content differs from generation sources")
            if current_sources != report.get("sources"):
                raise ValueError("runtime source bindings differ from editable brief")
            if editable_brief.get("figure_id") != entry.get("figure_id"):
                raise ValueError("generation brief figure_id differs from intent")
            if editable_brief.get("narrative_role", "mechanism") != entry.get("narrative_role"):
                raise ValueError("generation brief role differs from intent")
            if record.get("tool_name") != tool or record.get("request_sha256") != file_sha256(request_path):
                raise ValueError("tool record tool/request binding is stale")
            if record.get("output_sha256") != latex_hash:
                raise ValueError("tool record output binding is stale")
            response = record.get("response")
            if not isinstance(response, (dict, list)) or not response:
                raise ValueError("actual tool response must be retained")
            def has_tool_failure(value):
                if isinstance(value, list):
                    return any(has_tool_failure(child) for child in value)
                if not isinstance(value, dict):
                    return False
                if value.get("isError") or value.get("error") or str(value.get("status", "")).casefold() in {
                    "failed", "error", "cancelled", "canceled", "blocked", "rejected"
                }:
                    return True
                return any(has_tool_failure(child) for child in value.values() if isinstance(child, (dict, list)))
            if has_tool_failure(response):
                raise ValueError("failed tool response cannot substantiate native generation")
            if receipt.get("actual_backend") != backend or receipt.get("status") != "completed" or receipt.get("native_generation") is not True:
                errors.append(f"{prefix}: native generation receipt is not successful")
            if receipt.get("output_sha256") != latex_hash:
                errors.append(f"{prefix}: native receipt output hash mismatch")
            from PIL import Image
            image_path = Path(entry["latex_output"])
            image_path = image_path if image_path.is_absolute() else base_dir / image_path
            with Image.open(image_path) as native_image:
                native_image.load()
                if native_image.format != "PNG" or min(native_image.size) < 256:
                    raise ValueError("native output must be a real PNG of at least 256 pixels on each axis")
                if list(native_image.size) != report.get("pixel_size"):
                    raise ValueError("runtime pixel size differs from reopened native output")
        except (OSError, ValueError, KeyError, TypeError, AttributeError) as exc:
            errors.append(f"{prefix}: invalid native generation receipt: {exc}")
        reopen = report.get("reopen_check")
        if not isinstance(reopen, dict) or reopen.get("png") is not True or reopen.get("brief") is not True:
            errors.append(f"{prefix}: native output/brief reopen check required")
    else:
        reopen = report.get("reopen_check")
        if reopen is not True and not (isinstance(reopen, dict) and reopen and all(value is True for value in reopen.values())):
            errors.append(f"{prefix}.backend_report.reopen_check: a passing reopen report is required")

    source_data = entry.get("source_data")
    source_paths = collect_paths(source_data)
    source_hashes = {
        declared_hash_for_path(source_data, source, len(source_paths))
        for source in source_paths
        if HEX64_RE.fullmatch(declared_hash_for_path(source_data, source, len(source_paths)))
    }
    report_source_hashes: set[str] = set()
    value = report.get("input_sha256")
    if isinstance(value, str) and HEX64_RE.fullmatch(value.lower()):
        report_source_hashes.add(value.lower())
    for key in ("source", "spec"):
        value = report.get(key)
        if isinstance(value, dict) and isinstance(value.get("sha256"), str):
            report_source_hashes.add(str(value["sha256"]).lower())
    sources = report.get("sources")
    if isinstance(sources, list):
        for item in sources:
            if isinstance(item, dict) and isinstance(item.get("sha256"), str):
                report_source_hashes.add(str(item["sha256"]).lower())
    if source_hashes and not report_source_hashes:
        errors.append(f"{prefix}.backend_report: runtime report records no source/input hash")
    elif source_hashes and not source_hashes.issubset(report_source_hashes):
        missing = sorted(source_hashes - report_source_hashes)
        errors.append(f"{prefix}.backend_report: missing declared source hashes {', '.join(missing)}")
    return errors


def validate_entry(
    entry: dict[str, Any], index: int, base_dir: Path,
    require_sources: bool, require_outputs: bool, require_visual_review: bool = False,
) -> tuple[list[str], list[str]]:
    prefix = f"figures[{index}]"
    errors: list[str] = []
    warnings: list[str] = []

    for field in REQUIRED_FIGURE_FIELDS:
        if field not in entry or not nonempty(entry[field]):
            errors.append(f"{prefix}.{field}: required and must be non-empty")

    figure_id = str(entry.get("figure_id", ""))
    if figure_id and not re.fullmatch(r"[A-Za-z0-9_.-]+", figure_id):
        errors.append(f"{prefix}.figure_id: use letters, digits, '.', '_' or '-'")

    role = str(entry.get("narrative_role", "")).strip().lower()
    if role and role not in ROLE_SET:
        errors.append(f"{prefix}.narrative_role: expected one of {sorted(ROLE_SET)}")
    placement = str(entry.get("placement", "")).strip().lower()
    if placement and placement not in PLACEMENTS:
        errors.append(f"{prefix}.placement: expected one of {sorted(PLACEMENTS)}")
    exact_location = str(entry.get("exact_values_location", "")).strip().lower()
    if exact_location and exact_location not in EXACT_VALUE_LOCATIONS:
        errors.append(f"{prefix}.exact_values_location: unknown '{exact_location}'")
    takeaway = str(entry.get("reader_takeaway", "")).strip()
    if takeaway and len(takeaway) < 8:
        warnings.append(f"{prefix}.reader_takeaway: too vague; state the reader decision/understanding")
    if not ZH_RE.search(str(entry.get("caption_zh", ""))):
        warnings.append(f"{prefix}.caption_zh: no Chinese characters detected")

    chart = normalize_chart_type(entry.get("chart_or_diagram_type"))
    backend = str(entry.get("backend_preference", "")).strip().lower()
    if chart in DATA_TYPES and backend not in DATA_BACKENDS:
        errors.append(f"{prefix}: data chart '{chart}' incompatible with backend '{backend}'")
    elif chart in DIAGRAM_TYPES and backend not in DIAGRAM_BACKENDS:
        errors.append(f"{prefix}: diagram '{chart}' incompatible with backend '{backend}'")
    elif chart not in DATA_TYPES | DIAGRAM_TYPES:
        errors.append(f"{prefix}.chart_or_diagram_type: unrecognized '{chart}'")

    if chart in RESTRICTED_TYPES:
        if not specific_reason(entry.get("restricted_chart_justification")):
            errors.append(f"{prefix}.restricted_chart_justification: required for '{chart}'")
        if not specific_reason(entry.get("alternative_2d_check")):
            errors.append(f"{prefix}.alternative_2d_check: explain the 2D/3D tradeoff or companion view")
    if chart in {"surface_3d", "bar_3d", "scatter_3d", "surface_wireframe", "area_3d"} and not nonempty(entry.get("projection_or_exact_table")):
        errors.append(f"{prefix}.projection_or_exact_table: required for 3D figures")

    if bool(entry.get("internal_title", False)):
        errors.append(f"{prefix}.internal_title: use the LaTeX caption instead")
    if bool(entry.get("categorical_gradient", False)) and not nonempty(entry.get("color_encoding_variable")):
        errors.append(f"{prefix}.color_encoding_variable: categorical gradients require a real encoded variable")
    if bool(entry.get("significance_annotation", False)):
        for field in ("statistical_test", "comparison_family", "multiplicity_policy"):
            if not nonempty(entry.get(field)):
                errors.append(f"{prefix}.{field}: required for significance annotations")
    if chart == "errorbar":
        for field in ("uncertainty_type", "uncertainty_level", "sample_size_source"):
            if not nonempty(entry.get(field)):
                errors.append(f"{prefix}.{field}: required for error bars")
    if chart == "line_interval":
        for field in ("uncertainty_definition", "uncertainty_source"):
            if not nonempty(entry.get(field)):
                errors.append(f"{prefix}.{field}: required for precomputed interval bands")

    panel_count = entry.get("panel_count")
    if panel_count is not None:
        if not isinstance(panel_count, int) or panel_count < 1:
            errors.append(f"{prefix}.panel_count: must be a positive integer")
        elif panel_count > 4 and not specific_reason(entry.get("multi_panel_justification")):
            errors.append(f"{prefix}.multi_panel_justification: required when panel_count > 4")
        if isinstance(panel_count, int) and panel_count > 6 and placement == "body":
            errors.append(f"{prefix}.panel_count: >6 panels should move to appendix")

    if role == "orientation" and exact_location not in {"", "not_applicable"}:
        errors.append(f"{prefix}: orientation figures cannot be the source of exact result values")
    if role in {"evidence", "validation"} and exact_location == "not_applicable":
        errors.append(f"{prefix}: evidence/validation figures require an exact-value location")
    if role == "mechanism" and chart in DATA_TYPES:
        errors.append(f"{prefix}: mechanism role should use a structural/geometry diagram, not a data chart")
    if role in {"evidence", "validation"} and chart in DIAGRAM_TYPES:
        errors.append(f"{prefix}: evidence/validation roles cannot use a structural diagram")

    claim_ids = {claim.lower() for claim in normalized_claim_ids(entry.get("claim_id"))}
    if role in {"evidence", "validation"} and (not claim_ids or "not_applicable" in claim_ids):
        errors.append(f"{prefix}.claim_id: evidence/validation figures require real claim ids")
    if role == "validation":
        for field in ("validation_target", "validation_method"):
            if not nonempty(entry.get(field)):
                errors.append(f"{prefix}.{field}: required for validation figures")

    errors.extend(validate_visual_grammar(entry, prefix, require_outputs))

    editable = Path(str(entry.get("editable_output", "")))
    latex = Path(str(entry.get("latex_output", "")))
    if backend == "origin" and editable.suffix.lower() != ".opju":
        errors.append(f"{prefix}.editable_output: Origin output must use .opju")
    if backend == "visio" and editable.suffix.lower() != ".vsdx":
        errors.append(f"{prefix}.editable_output: Visio output must use .vsdx")
    if backend in {"figurespec", "figurespec/svg", "svg"} and editable.suffix.lower() not in {".json", ".svg"}:
        errors.append(f"{prefix}.editable_output: FigureSpec/SVG source must use .json or .svg")
    if backend in {"python", "python/matplotlib", "matplotlib"} and editable.suffix.lower() not in {".py", ".json", ".ipynb"}:
        errors.append(f"{prefix}.editable_output: Python source must use .py, .json or .ipynb")
    if backend == "matlab" and editable.suffix.lower() not in {".fig", ".m", ".json"}:
        errors.append(f"{prefix}.editable_output: MATLAB source must use .fig, .m or .json")
    if backend == "mermaid" and editable.suffix.lower() not in {".mmd", ".md"}:
        errors.append(f"{prefix}.editable_output: Mermaid source must use .mmd or .md")
    if backend in GENERATIVE_BACKENDS:
        if editable.suffix.lower() != ".json" or entry.get("editability") != "prompt_and_spec_only":
            errors.append(f"{prefix}.editable_output: native raster requires JSON brief and prompt_and_spec_only")
        if latex.suffix.lower() != ".png":
            errors.append(f"{prefix}.latex_output: native image must remain a real PNG")
        if role not in {"orientation", "mechanism"}:
            errors.append(f"{prefix}: native image generation cannot render quantitative evidence")
        if chart in {"geometry", "coordinate_system", "free_body_diagram"} or entry.get("exact_geometry_required"):
            errors.append(f"{prefix}: exact geometry requires deterministic rendering")
    if latex.suffix.lower() not in {".pdf", ".png"}:
        errors.append(f"{prefix}.latex_output: expected .pdf or .png")
    elif latex.suffix.lower() == ".png" and chart != "map" and backend not in GENERATIVE_BACKENDS:
        warnings.append(f"{prefix}.latex_output: vector PDF is preferred")

    variables = entry.get("variables")
    units = entry.get("units")
    if isinstance(variables, list) and isinstance(units, dict):
        missing_units = [str(variable) for variable in variables if str(variable) not in units]
        if missing_units:
            warnings.append(f"{prefix}.units: no unit entry for {', '.join(missing_units)}")

    if require_sources:
        source_data = entry.get("source_data")
        source_paths = collect_paths(source_data)
        if not source_paths:
            errors.append(f"{prefix}.source_data: no source path found")
        for source in source_paths:
            candidate = Path(source)
            if not candidate.is_absolute():
                candidate = base_dir / candidate
            if not candidate.is_file():
                errors.append(f"{prefix}.source_data: missing {candidate}")
                continue
            declared = declared_hash_for_path(source_data, source, len(source_paths))
            if not HEX64_RE.fullmatch(declared):
                errors.append(f"{prefix}.source_data.sha256: 64-char hash required for {source}")
            elif file_sha256(candidate) != declared:
                errors.append(f"{prefix}.source_data.sha256: mismatch for {candidate}")

    if require_outputs:
        resolved_hashes: dict[str, str] = {}
        for field, path_value, hash_field in (
            ("editable_output", editable, "editable_sha256"),
            ("latex_output", latex, "latex_sha256"),
        ):
            candidate = path_value if path_value.is_absolute() else base_dir / path_value
            if not candidate.is_file():
                errors.append(f"{prefix}.{field}: missing {candidate}")
                continue
            declared = str(entry.get(hash_field, "")).strip().lower()
            if not HEX64_RE.fullmatch(declared):
                errors.append(f"{prefix}.{hash_field}: 64-char SHA-256 required")
            elif file_sha256(candidate) != declared:
                errors.append(f"{prefix}.{hash_field}: mismatch for {candidate}")
            else:
                resolved_hashes[field] = declared
            reopen_error = basic_output_reopen_error(candidate)
            if reopen_error:
                errors.append(f"{prefix}.{field}: {reopen_error}: {candidate}")
        errors.extend(validate_backend_report(
            entry, prefix, base_dir,
            resolved_hashes.get("editable_output", ""),
            resolved_hashes.get("latex_output", ""),
        ))
        if require_visual_review or entry.get("style_reference") or backend in GENERATIVE_BACKENDS:
            from visual_review_contract import validate_review
            errors.extend(f"{prefix}: {err}" for err in validate_review(entry, base_dir))

    return errors, warnings


def value_at_dotted_field(payload: Any, field: str) -> Any:
    value = payload
    for part in field.split("."):
        if not isinstance(value, dict) or part not in value:
            raise KeyError(field)
        value = value[part]
    return value


def normalize_task_block(question: dict[str, Any]) -> dict[str, dict[str, Any]]:
    """Support the new task schema and the previous slot schema during migration."""
    if isinstance(question.get("tasks"), dict):
        return question["tasks"]
    slots = question.get("slots")
    if not isinstance(slots, dict):
        return {}
    converted: dict[str, dict[str, Any]] = {}
    mapping = {
        "data_diagnosis": "orientation",
        "mechanism": "mechanism",
        "main_result": "main_result",
        "comparison": "comparison",
        "validation": "validation",
        "robustness": "robustness",
    }
    for old_name, task_name in mapping.items():
        slot = slots.get(old_name)
        if not isinstance(slot, dict):
            continue
        ids = slot.get("figure_ids", [])
        if isinstance(ids, list) and ids:
            converted[task_name] = {
                "representation": "figure",
                "figure_ids": ids,
                "reason": slot.get("reason") or "legacy slot migrated as figure",
            }
        else:
            converted[task_name] = {
                "representation": "not_applicable",
                "figure_ids": [],
                "reason": slot.get("omission_reason") or "legacy slot has no figure",
            }
    return converted


def validate_coverage(document: Any, entries: list[dict[str, Any]], base_dir: Path) -> tuple[list[str], dict[str, Any]]:
    """Validate reader-task coverage without any per-question figure-count requirement."""
    errors: list[str] = []
    warnings: list[str] = []
    summary: dict[str, Any] = {
        "question_count": 0,
        "body_figure_count": 0,
        "questions": [],
        "warnings": warnings,
    }
    if not isinstance(document, dict) or not isinstance(document.get("coverage_plan"), dict):
        return ["coverage_plan: required in coverage mode"], summary

    plan = document["coverage_plan"]
    questions = plan.get("questions")
    if not isinstance(questions, list) or not questions:
        return ["coverage_plan.questions: must be a non-empty list"], summary

    expected_ids = plan.get("expected_question_ids")
    if not isinstance(expected_ids, list) or not expected_ids or not all(isinstance(item, str) and item.strip() for item in expected_ids):
        errors.append("coverage_plan.expected_question_ids: must list every expected question")
        expected_ids = []
    elif len(set(expected_ids)) != len(expected_ids):
        errors.append("coverage_plan.expected_question_ids: duplicate question id")

    expected_source = plan.get("expected_question_ids_source")
    if isinstance(expected_source, dict):
        paths = collect_paths(expected_source)
        field = str(expected_source.get("field", "")).strip()
        if len(paths) == 1 and field:
            source_path = Path(paths[0])
            if not source_path.is_absolute():
                source_path = base_dir / source_path
            declared = declared_hash_for_path(expected_source, paths[0], 1)
            if not source_path.is_file():
                errors.append(f"coverage_plan.expected_question_ids_source.file: missing {source_path}")
            elif not HEX64_RE.fullmatch(declared) or file_sha256(source_path) != declared:
                errors.append("coverage_plan.expected_question_ids_source.sha256: missing or mismatched")
            else:
                try:
                    payload = load_document(source_path)
                    source_ids = value_at_dotted_field(payload, field)
                    if not isinstance(source_ids, list):
                        errors.append("coverage_plan.expected_question_ids_source.field: must resolve to a list")
                    elif {str(item).strip() for item in source_ids} != {str(item).strip() for item in expected_ids}:
                        errors.append("coverage_plan.expected_question_ids does not match decomposition source")
                except Exception as exc:
                    errors.append(f"coverage_plan.expected_question_ids_source: {type(exc).__name__}: {exc}")
        else:
            errors.append("coverage_plan.expected_question_ids_source: exactly one file and a field are required")
    else:
        errors.append("coverage_plan.expected_question_ids_source: required")

    by_id = {str(entry.get("figure_id", "")): entry for entry in entries}
    planned: set[str] = set()
    used_figures: set[str] = set()
    summary["question_count"] = len(questions)

    for index, question in enumerate(questions):
        prefix = f"coverage_plan.questions[{index}]"
        if not isinstance(question, dict):
            errors.append(f"{prefix}: must be an object")
            continue
        qid = str(question.get("question_id", "")).strip()
        if not qid:
            errors.append(f"{prefix}.question_id: required")
            continue
        if qid in planned:
            errors.append(f"{prefix}.question_id: duplicate '{qid}'")
        planned.add(qid)

        tasks = normalize_task_block(question)
        if not tasks:
            errors.append(f"{prefix}.tasks: define reader tasks with a representation")
            continue

        q_figure_ids: list[str] = []
        for task_name, task in tasks.items():
            task_prefix = f"{prefix}.tasks.{task_name}"
            if task_name not in READER_TASKS:
                warnings.append(f"{task_prefix}: nonstandard reader task")
            if not isinstance(task, dict):
                errors.append(f"{task_prefix}: must be an object")
                continue
            representation = str(task.get("representation", "")).strip().lower()
            if representation not in REPRESENTATIONS:
                errors.append(f"{task_prefix}.representation: expected one of {sorted(REPRESENTATIONS)}")
                continue
            if not specific_reason(task.get("reason")):
                errors.append(f"{task_prefix}.reason: explain the reader-task choice in at least 8 characters")
            figure_ids = task.get("figure_ids", [])
            if figure_ids is None:
                figure_ids = []
            if not isinstance(figure_ids, list) or not all(isinstance(fid, str) and fid for fid in figure_ids):
                errors.append(f"{task_prefix}.figure_ids: must be a list")
                figure_ids = []
            if representation == "figure" and not figure_ids:
                errors.append(f"{task_prefix}: representation=figure requires figure_ids")
            if representation != "figure" and figure_ids:
                warnings.append(f"{task_prefix}: figure_ids present while representation='{representation}'")

            for figure_id in figure_ids:
                entry = by_id.get(figure_id)
                if entry is None:
                    errors.append(f"{task_prefix}.figure_ids: unknown figure '{figure_id}'")
                    continue
                if str(entry.get("question_id", "")).strip() != qid:
                    errors.append(f"{task_prefix}: figure '{figure_id}' belongs to another question")
                if figure_id in used_figures:
                    warnings.append(f"{task_prefix}: figure '{figure_id}' is reused; verify it has one clear primary task")
                used_figures.add(figure_id)
                q_figure_ids.append(figure_id)

        body_ids = [
            fid for fid in q_figure_ids
            if str(by_id.get(fid, {}).get("placement", "")).lower() == "body"
        ]
        summary["body_figure_count"] += len(set(body_ids))
        summary["questions"].append({
            "question_id": qid,
            "planned_task_count": len(tasks),
            "figure_count": len(set(q_figure_ids)),
            "body_figure_count": len(set(body_ids)),
        })

    expected = {str(item).strip() for item in expected_ids}
    for qid in sorted(expected - planned):
        errors.append(f"coverage_plan.questions: missing expected question '{qid}'")
    for qid in sorted(planned - expected):
        errors.append(f"coverage_plan.expected_question_ids: missing planned question '{qid}'")

    figure_qids = {
        str(entry.get("question_id", "")).strip()
        for entry in entries
        if str(entry.get("question_id", "")).strip().lower() not in {"", "paper"}
    }
    for qid in sorted(figure_qids - planned):
        errors.append(f"coverage_plan.questions: missing plan for figure question '{qid}'")

    for entry in entries:
        fid = str(entry.get("figure_id", ""))
        qid = str(entry.get("question_id", "")).strip().lower()
        if qid != "paper" and fid not in used_figures:
            errors.append(f"figure '{fid}' is not assigned to any reader task")

    return errors, summary


def validate_grammar_groups(entries: list[dict[str, Any]]) -> list[str]:
    errors: list[str] = []
    by_group: dict[str, str] = {}
    for index, entry in enumerate(entries):
        group = str(entry.get("visual_grammar_group", ""))
        grammar = entry.get("visual_grammar")
        if group and isinstance(grammar, dict):
            signature = json.dumps(grammar, ensure_ascii=False, sort_keys=True)
            if group in by_group and by_group[group] != signature:
                errors.append(f"figures[{index}].visual_grammar conflicts with group '{group}'")
            else:
                by_group[group] = signature
    return errors


def validate_distinct_outputs(entries: list[dict[str, Any]]) -> list[str]:
    errors: list[str] = []
    owner: dict[tuple[str, str], str] = {}
    for entry in entries:
        fid = str(entry.get("figure_id", ""))
        for field in ("latex_sha256", "editable_sha256", "backend_report_sha256"):
            value = str(entry.get(field, "")).strip().lower()
            if not HEX64_RE.fullmatch(value):
                continue
            key = (field, value)
            if key in owner and owner[key] != fid:
                errors.append(f"figures '{owner[key]}' and '{fid}' reuse the same {field} artifact")
            else:
                owner[key] = fid
    return errors


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Validate reader-task figure plans while retaining strict rendering artifact checks"
    )
    parser.add_argument("intent_file", type=Path)
    parser.add_argument("--base-dir", type=Path, default=None)
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--require-sources", dest="require_sources", action="store_true")
    group.add_argument("--allow-missing-sources", dest="require_sources", action="store_false")
    parser.set_defaults(require_sources=True)
    parser.add_argument("--require-outputs", action="store_true")
    parser.add_argument("--require-visual-review", action="store_true",
                        help="Require hash-bound independent reference-based visual reviews for final figures")
    parser.add_argument("--require-coverage", action="store_true")
    parser.add_argument("--strict", action="store_true")
    parser.add_argument("--output", type=Path, default=None)
    args = parser.parse_args()
    if args.require_visual_review and not args.require_outputs:
        parser.error("--require-visual-review needs --require-outputs (final artifact mode)")

    report: dict[str, Any] = {
        "checker": "figure-intent-reader-task-and-artifact-integrity",
        "semantic_claim_validation": False,
        "fixed_figure_quota": False,
        "output_integrity_check": bool(args.require_outputs),
        "coverage_check": bool(args.require_coverage),
        "input": str(args.intent_file.resolve()),
        "status": "FAILED",
        "figure_count": 0,
        "errors": [],
        "warnings": [],
    }
    try:
        document = load_document(args.intent_file)
        entries = normalize_entries(document)
        report["figure_count"] = len(entries)
        seen: set[str] = set()
        base_dir = (args.base_dir or args.intent_file.parent).resolve()
        for index, entry in enumerate(entries):
            errors, warnings = validate_entry(
                entry, index, base_dir, args.require_sources, args.require_outputs, args.require_visual_review
            )
            report["errors"].extend(errors)
            report["warnings"].extend(warnings)
            fid = str(entry.get("figure_id", ""))
            if fid in seen:
                report["errors"].append(f"figures[{index}].figure_id: duplicate '{fid}'")
            seen.add(fid)
        report["errors"].extend(validate_grammar_groups(entries))
        if args.require_outputs:
            report["errors"].extend(validate_distinct_outputs(entries))
        if args.require_coverage:
            coverage_errors, summary = validate_coverage(document, entries, base_dir)
            report["errors"].extend(coverage_errors)
            report["coverage_summary"] = summary
            report["warnings"].extend(summary.get("warnings", []))
    except Exception as exc:
        report["errors"].append(f"{type(exc).__name__}: {exc}")

    failed = bool(report["errors"] or (args.strict and report["warnings"]))
    report["status"] = "FAILED" if failed else "PASSED"
    rendered = json.dumps(report, ensure_ascii=False, indent=2)
    print(rendered)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered + "\n", encoding="utf-8")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
